# 에셋 출처와 재사용

## 1~3세대 포켓몬 스프라이트

- 출처: [PokéAPI/sprites](https://github.com/PokeAPI/sprites), 커밋 `0dc105d5b12416932f29b594078282ab4be045f5`.
- 경로: `sprites/pokemon/{1..386}.png`, `sprites/pokemon/back/{1..386}.png`. 96×96 투명 PNG, 원본 픽셀을 변형하지 않고 포함한다. 앞·뒤 총 772장이다.
- 로컬 경로: `assets/pokemon/front/001.png` ~ `386.png`, `assets/pokemon/back/001.png` ~ `386.png`.
- [업스트림 라이선스](assets/sources/POKEAPI_SPRITES_LICENSE.txt)는 **이미지 저작권이 The Pokémon Company에 있음**을 명시한다. 저장소의 CC0 표기는 원작 포켓몬 이미지의 권리를 이전하지 않는다. 출처를 유지하고 외부 배포 시 권리 범위를 별도로 확인한다.

## 이름·타입·기술 데이터

- 출처: [PokéAPI/pokeapi](https://github.com/PokeAPI/pokeapi), 커밋 `81d20919845b6a445969b9265aab5cec6b04cece`, `data/v2/csv`.
- 원본 CSV와 [라이선스](assets/sources/POKEAPI_DATA_LICENSE.txt)를 `assets/sources/`에 보관했다.
- `data/catalog.json`은 1~3세대 원종 386종과 1세대 기술 165종을 추린 로컬 카탈로그다. 타입은 현대 분류와 복합타입을 유지하며 세대·지역·진화 전 종·아기·전설·환상 플래그를 기록한다. 지역폼·메가진화·별도 폼은 포함하지 않는다.
- `data/evolutions.json`은 같은 고정 커밋의 `pokemon_evolution.csv`에서 기본형의 조건 없는 레벨 진화 135개를 추렸다. 원본 CSV도 보관하며 돌·친밀도·통신·성별·랜덤·폼 등의 조건은 일반 레벨 진화로 포함하지 않는다. 전투 경험치 배율은 이 게임이 작성했고, 능력치 계산은 별도 종족값 데이터와 레벨을 사용한다.
- `data/progression.json`은 같은 고정 커밋의 6개 성장 곡선, 386종 성장 그룹, 354개 기술 메타데이터와 에메랄드 레벨별 기술표를 사용한다. 테오키스 원종은 루비·사파이어 기술표를 보완한다. 필터링한 `pokemon_moves_emerald.csv`의 해시와 전체 원본 해시를 모두 기록하며 `tools/build_progression.py`로 재생성한다. 배틀 효과·에너지·경험치 배율은 이 게임의 수치다.
- `data/type_chart.json`은 같은 고정 커밋의 `type_efficacy.csv`에서 현대 18개 타입의 324개 상성을 가져온다. 원본 CSV·URL·SHA-256을 보관하며 `tools/build_type_chart.py`로 재생성한다. `data/league.json`의 사천왕·챔피언 파티는 1~3세대 범위에 맞춰 이 프로젝트가 작성했다.
- `data/base_stats.json`은 같은 고정 커밋의 `pokemon_stats.csv`와 `pokemon_stats_past.csv`에서 386종의 3세대 당시 여섯 종족값을 복원한다. 과거 값의 `generation_id`는 해당 값이 적용된 마지막 세대를 뜻하므로, 각 종·능력치에서 3 이상인 가장 이른 경계를 선택한다. 원본 CSV·SHA-256을 보관하며 `tools/build_stats.py`로 재생성한다. 개체값·노력치·성격 고정과 전투 배율은 프로젝트 규칙이다.
- 기술의 VFX 프로필은 이 프로젝트가 작성한 표현용 매핑이다. 상태 확률·피해량·사용 가능 기술을 구현한 데이터가 아니다. 프리뷰에서는 어떤 포켓몬으로도 연출을 확인할 수 있다.
- 바이옴의 출현 등급과 가중치 8:3:1은 종별 상대 가중치 초안이다. 등급 전체의 출현 확률이나 실제 원작 서식 분포를 뜻하지 않는다. 전설·환상 21종은 일반 가중치 풀과 관장 편성에서 제외했다. 18개 타입 관장의 6마리 파티는 이 프로젝트가 작성한 편성이며 특정 원작 버전의 파티를 복제하지 않는다.

## 배경과 기술 이펙트

- 바이옴 배경: 기존 2열×3행 아틀라스 3장을 2026-10-16에 `image_gen`으로 다시 그렸다. 18개 타입의 순서와 경로를 유지하고 큰 픽셀 군집·단순한 색면·열린 전투 지형으로 바꿨다. 첫 아틀라스의 같은 높이 발판도 아군 왼쪽 아래·상대 오른쪽 위의 구도로 수정했다. 원작 게임 배경을 내려받은 에셋이 아니다.
- 생성 방향: 16비트 RPG 픽셀 아트, 동일한 전투 시점, 전경에 포켓몬이 설 공간, 글자·캐릭터·UI·구분선 제외. 원본 생성 파일은 `/workspace/generated_images`에 보존하고 프로젝트에는 복사본을 포함한다.
- `assets/biomes/atlas_1.png`: 불꽃 / 물 / 풀 / 노말 / 전기 / 얼음 순서.
- `assets/biomes/atlas_2.png`: 격투 / 독 / 땅 / 비행 / 에스퍼 / 벌레 순서.
- `assets/biomes/atlas_3.png`: 바위 / 고스트 / 드래곤 / 악 / 강철 / 페어리 순서.
- 리그 실내 배경: 2026-10-16에 `image_gen`으로 생성한 `assets/league/elite_{1..3}.png`, `champion_{1..2}.png` 5장이다. 타입 룸 18개(현재 사천왕 후보는 14타입 사용), 현재 챔피언 11명의 지방별 변형과 공용 홀 1개를 포함한다. 원작 룸을 추출하지 않고 타입·지방 건축과 분위기를 참고해 생성했다. 셀 순서와 현재 후보 연결은 [리그 스테이지](docs/league-stages.md), `data/battle_backdrops.json`에 기록한다.
- 바이옴·리그 원본은 각각 1536×1024의 2열×3행 PNG다. 셀 하나는 약 768×341이며 개별 1920×1080 또는 정확한 16:9 원본이 아니다. 게임에서는 최근접 필터로 확대하고 손패 위 전투 지형과 발밑을 기준으로 프레이밍한다. 아틀라스별 SHA-256은 `assets/biomes/manifest.json`, `assets/league/manifest.json`에 기록했다. 생성 원본은 `/workspace/generated_images`에 보존하고 복사본을 프로젝트에 사용했다.
- 관장·사천왕·챔피언 대진 75개에 Smogon / Pokémon Showdown의 원작 정면 도트 73장을 적용했다. 고정 커밋 `a9214714f00974a8c28586829e6315d9ca5a6348`, `src/_uncategorized/canonical/trainers/`에서 원본 PNG를 수정 없이 가져왔다. 대진/URL/SHA/투명 경계는 `assets/sources/trainer_sprites.json`, 출처 원문은 `assets/sources/SMOGON_SPRITES_README.md`다. 그림은 Nintendo / Game Freak / The Pokémon Company 소유이며 저장소 코드의 MIT 허가와 구분한다. 후대 인물 49대진과 일반 상대는 기존 자체 공용 도트를 유지한다. [6~9세대 후보](docs/trainer-sprite-links.md)는 별도로 찾았고 갤러리의 제작자 표기·무단 편집 금지 조건을 확인했지만 아직 다운로드/적용하지 않았다. [적용 범위·재검증](docs/trainer-presentation.md)을 참고한다. 포켓볼은 아래 PokéAPI 아이템 원본이다.
- 모두 왼쪽 위부터 행 우선 순서다. `data/biomes.json`의 `background`, `cell`로 연결한다. `VisualCatalog.biome_texture()`가 `AtlasTexture`를 반환한다.
- 기술 연출은 외부 애니메이션을 복제하지 않고 `scripts/vfx/move_effect.gd`에 도형으로 작성했다. 이펙트 데이터, 씬 표현과 향후 전투 규칙을 분리했다.
- 그래픽 에셋은 도트 스타일로 사용하되 화면과 UI는 **1920×1080**에서 그린다. 전체 화면을 축소하는 SubViewport는 사용하지 않는다. 스프라이트의 최근접 필터·정수 배율을 유지하고 도형의 안티앨리어싱과 텍스처 흐림은 끈다.

## UI 아이콘

- `assets/ui/icons/*.svg` 45종 중 **타입 18종**은 사용자 검토 후 승인받은 [duiker101/pokemon-type-svg-icons](https://github.com/duiker101/pokemon-type-svg-icons) 기호 세트, 고정 커밋 `5781623f147f1bf850f426cfe1874ba56a9b75ee`에서 가져왔다. 나머지 시작 화면·포획·회복·배지·야영 보급품 등의 **27종은 프로젝트가 작성한 16×16 도트 아이콘**이다.
- 타입 원본은 업스트림 `icons/{type}.svg`의 흰색 기호다. 기호의 경로를 유지하고 업스트림 CSS의 타입 색상·20% 여백·60% 기호 비율을 적용해 **32×32 원형 배지 SVG**로 감쌌다. Godot에서 32px 텍스처로 임포트하고 기존 20/24/32px UI 칸에 최근접 필터로 표시한다. 화면 전체 해상도나 스프라이트는 바꾸지 않는다.
- 원본 SVG·README·CSS는 `assets/sources/type-icons/*.txt`에 원문 그대로 보관한다. 업스트림 README의 소개는 “Very simple set of SVG icons for Pokemon types for any use.”이며 [원본 디자인 링크](https://dribbble.com/shots/4862612-Pokedex-iOS-app)를 제공한다. 이 고정 커밋에는 별도 LICENSE 파일이 없으므로 MIT 등 별도 라이선스로 표시하지 않는다. 공식 게임에서 추출한 이미지가 아니라 공개 SVG 기호 재현 세트다.
- 고정 URL과 원본/적용 파일 SHA-256, 배경색·크기는 `assets/sources/type_icons.json`에 기록한다. `python3 tools/import_type_icons.py --offline`으로 보관된 원본에서 재현하고 `--check`로 다운로드·수정 없이 검증한다. 원본이 없으면 옵션 없이 실행해 고정 URL에서 다시 가져오며 기록된 해시와 일치해야 한다. 게임 실행에는 네트워크를 사용하지 않는다.
- 에너지·공격·방어·타입·상태·드로우·교체·메뉴 등의 기호를 최근접 필터로 확대한다. 아이콘과 작은 수치를 함께 표시하고, 효과 설명은 툴팁·도움말로 제공한다.
- 트레이너 카드의 일러스트 6종은 `scripts/ui/trainer_card_art.gd`에서 직접 작성한 84×48 도트 장면을 2배로 그린다. 기존 UI 아이콘과 지도·방어물·서류·깃발·구급 상자 등의 도형을 조합하며 외부 일러스트나 원작 카드 이미지를 사용하지 않는다.
- 포켓몬 초상은 기존 스프라이트의 투명 여백을 런타임 `AtlasTexture`로 제외해 정수 배율로 표시한다. 큰 종의 작은 UI 초상은 필요하면 1/2·1/3의 정수 분모로 축소해 영역 안에 맞추고 최근접 필터를 유지한다. 원본 파일은 유지한다.

### 카드 효과 도트 기호

2026-10-16에 초록 하트·빨간 칼·파란 방패·소진 카드를 정리하고 특공·방어·특방·스피드·전 능력, 화상·독·수면·마비·혼란·치료의 16×16 SVG를 저장소에서 직접 작성했다. 외부 이미지를 추가 다운로드하지 않았다. `CardEffectText`와 전투 HUD/연출에서 최근접 필터로 표시하며, 승인된 18개 타입 배지와 원본/해시 manifest는 수정하지 않는다. [카드 효과 아이콘](docs/card-effect-icons.md)에 범위와 표시 규칙을 기록한다.

## 한국어 폰트

- [Google Fonts / Noto Sans KR](https://github.com/google/fonts/tree/main/ofl/notosanskr), 커밋 `e9678a5385322c63730122ba464765baad83cfd8`.
- `assets/fonts/NotoSansKR.ttf`와 [SIL Open Font License](assets/fonts/OFL.txt)를 포함한다.

## 재현

`python3 tools/import_pokemon_assets.py`로 고정 커밋에서 원본을 가져오고 `python3 tools/build_biomes.py`로 출현·관장 데이터와 목록 문서를 재생성한다. 이전 `import_kanto_assets.py`는 호환용 진입점으로 유지한다. 모든 다운로드는 HTTPS 검증을 유지하며, 파일별 URL과 SHA-256은 `assets/sources/manifest.json`에 기록한다. 타입 배지는 별도 `assets/sources/type_icons.json`과 `tools/import_type_icons.py`로 관리한다. 동일한 파일은 재사용하며 실패한 다운로드가 있어도 완료된 파일을 재사용할 수 있다. 배경은 생성 에셋이므로 네트워크 임포터가 덮어쓰지 않는다.

## 가방 아이템

- `assets/items/{potion,super_potion,revive,ball}.png`는 같은 PokéAPI/sprites 고정 커밋의 `sprites/items/{potion,super-potion,revive,poke-ball}.png`에서 가져온 30×30 PNG 네 장이다. 상처약·좋은상처약·기력의조각·몬스터볼을 야영지 가방·대상 선택·상점과 포켓볼 교체 연출에 사용한다.
- 진화 재료 PNG 13장을 같은 고정 커밋에서 추가했다. 돌 6종, 왕의징표석·금속코트·용의비늘·업그레이드·심해의이빨·심해의비늘은 해당 원본 아이템 그림이다. 원본 파일 `up-grade.png`는 로컬 `upgrade.png`로 저장한다. 고정 커밋에 연결의끈 그림이 없어 `escape-rope.png`를 로컬 `linking_cord.png`로 재사용했다. 모든 원본 URL·SHA-256은 manifest에 명시한다. 총 17장이다.
- 돌·통신 진화 33개 기본형 경로는 고정 `pokemon_evolution.csv`와 종별 진화 전 ID로 검증하며, 싱글플레이 통신 대체 방식과 상점 가격은 이 게임의 규칙이다. 친밀도·시간대 진화 9경로도 같은 CSV와 대조하며 기준 220은 3세대 규칙, 초기값과 원정 행동별 획득량은 게임용 조정값이다. [진화 재료](docs/evolution-items.md)를 참고한다.
- `blue_pokeblock.png`는 같은 고정 커밋의 `sprites/items/blue-shard.png`를 간소화한 원정용 파랑포켓블록 그림으로 재사용한다. 가방 아이템은 이를 포함해 총 18장이다. 포켓블록 품질·가격·효과, 배루키 훈련은 이 게임의 규칙이며 [특수 진화](docs/special-evolution.md)에 명시한다.
- 원작 이미지 권리는 위 포켓몬 스프라이트와 동일하다. `python3 tools/build_item_assets.py`로 재생성하며 원본 크기·URL·SHA-256을 검사·기록한다. 실행 중 네트워크는 사용하지 않는다.
