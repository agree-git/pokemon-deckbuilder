포켓몬 배경 위치 수정

HTML을 브라우저로 열고 배경을 선택한 뒤 포켓몬을 드래그하세요.
최신 초기값은 사용자가 올린 JSON을 반영한 좌표입니다.
수정 후 JSON 저장을 누르고 battlefield_layouts.json을 보관하거나 전달하세요.
직접 적용하려면 게임 종료 후 프로젝트의 data/battlefield_layouts.json을 교체하고 다시 실행하세요.
